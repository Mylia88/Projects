﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalariesDll
{
    public enum ConnectionResult
    {
        Connecté=0,
        MotPasseInvalide = 2,
        CompteBloqué = 3
    }
}
