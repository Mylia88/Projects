﻿namespace GestionSalaraies
{
    partial class FrmSalaries
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbDetailSalarié = new System.Windows.Forms.GroupBox();
            this.pnlBoutons = new System.Windows.Forms.Panel();
            this.btnValider = new System.Windows.Forms.Button();
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.btnModifier = new System.Windows.Forms.Button();
            this.txtNomS = new System.Windows.Forms.TextBox();
            this.txtDateNaissance = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMatricule = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cbSalarié = new System.Windows.Forms.ComboBox();
            this.btnNouveauS = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.chkCompteBloque = new System.Windows.Forms.CheckBox();
            this.gbDetailSalarié.SuspendLayout();
            this.pnlBoutons.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbDetailSalarié
            // 
            this.gbDetailSalarié.Controls.Add(this.label8);
            this.gbDetailSalarié.Controls.Add(this.label7);
            this.gbDetailSalarié.Controls.Add(this.textBox3);
            this.gbDetailSalarié.Controls.Add(this.textBox2);
            this.gbDetailSalarié.Controls.Add(this.label6);
            this.gbDetailSalarié.Controls.Add(this.textBox1);
            this.gbDetailSalarié.Controls.Add(this.chkCompteBloque);
            this.gbDetailSalarié.Controls.Add(this.pnlBoutons);
            this.gbDetailSalarié.Controls.Add(this.txtNomS);
            this.gbDetailSalarié.Controls.Add(this.txtDateNaissance);
            this.gbDetailSalarié.Controls.Add(this.label4);
            this.gbDetailSalarié.Controls.Add(this.label3);
            this.gbDetailSalarié.Controls.Add(this.txtMatricule);
            this.gbDetailSalarié.Controls.Add(this.label2);
            this.gbDetailSalarié.Location = new System.Drawing.Point(24, 91);
            this.gbDetailSalarié.Margin = new System.Windows.Forms.Padding(2);
            this.gbDetailSalarié.Name = "gbDetailSalarié";
            this.gbDetailSalarié.Padding = new System.Windows.Forms.Padding(2);
            this.gbDetailSalarié.Size = new System.Drawing.Size(359, 328);
            this.gbDetailSalarié.TabIndex = 7;
            this.gbDetailSalarié.TabStop = false;
            this.gbDetailSalarié.Text = "Détails Salarié";
            // 
            // pnlBoutons
            // 
            this.pnlBoutons.Controls.Add(this.btnValider);
            this.pnlBoutons.Controls.Add(this.btnAnnuler);
            this.pnlBoutons.Controls.Add(this.btnModifier);
            this.pnlBoutons.Location = new System.Drawing.Point(16, 232);
            this.pnlBoutons.Margin = new System.Windows.Forms.Padding(2);
            this.pnlBoutons.Name = "pnlBoutons";
            this.pnlBoutons.Size = new System.Drawing.Size(325, 60);
            this.pnlBoutons.TabIndex = 3;
            // 
            // btnValider
            // 
            this.btnValider.Location = new System.Drawing.Point(163, 17);
            this.btnValider.Margin = new System.Windows.Forms.Padding(2);
            this.btnValider.Name = "btnValider";
            this.btnValider.Size = new System.Drawing.Size(56, 23);
            this.btnValider.TabIndex = 0;
            this.btnValider.Text = "Valider";
            this.btnValider.UseVisualStyleBackColor = true;
            // 
            // btnAnnuler
            // 
            this.btnAnnuler.Location = new System.Drawing.Point(92, 17);
            this.btnAnnuler.Margin = new System.Windows.Forms.Padding(2);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(56, 23);
            this.btnAnnuler.TabIndex = 0;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.UseVisualStyleBackColor = true;
            // 
            // btnModifier
            // 
            this.btnModifier.Location = new System.Drawing.Point(17, 17);
            this.btnModifier.Margin = new System.Windows.Forms.Padding(2);
            this.btnModifier.Name = "btnModifier";
            this.btnModifier.Size = new System.Drawing.Size(56, 23);
            this.btnModifier.TabIndex = 0;
            this.btnModifier.Text = "Modifier";
            this.btnModifier.UseVisualStyleBackColor = true;
            // 
            // txtNomS
            // 
            this.txtNomS.Location = new System.Drawing.Point(129, 45);
            this.txtNomS.Margin = new System.Windows.Forms.Padding(2);
            this.txtNomS.Name = "txtNomS";
            this.txtNomS.Size = new System.Drawing.Size(132, 20);
            this.txtNomS.TabIndex = 1;
            // 
            // txtDateNaissance
            // 
            this.txtDateNaissance.Location = new System.Drawing.Point(129, 93);
            this.txtDateNaissance.Margin = new System.Windows.Forms.Padding(2);
            this.txtDateNaissance.Name = "txtDateNaissance";
            this.txtDateNaissance.PasswordChar = '*';
            this.txtDateNaissance.Size = new System.Drawing.Size(132, 20);
            this.txtDateNaissance.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 48);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Nom :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 96);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Data de Naissance :";
            // 
            // txtMatricule
            // 
            this.txtMatricule.Location = new System.Drawing.Point(129, 21);
            this.txtMatricule.Margin = new System.Windows.Forms.Padding(2);
            this.txtMatricule.Name = "txtMatricule";
            this.txtMatricule.Size = new System.Drawing.Size(132, 20);
            this.txtMatricule.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 24);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Matricule :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 42);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Choisir un salarié :";
            // 
            // cbSalarié
            // 
            this.cbSalarié.FormattingEnabled = true;
            this.cbSalarié.Location = new System.Drawing.Point(133, 37);
            this.cbSalarié.Margin = new System.Windows.Forms.Padding(2);
            this.cbSalarié.Name = "cbSalarié";
            this.cbSalarié.Size = new System.Drawing.Size(166, 21);
            this.cbSalarié.TabIndex = 5;
            // 
            // btnNouveauS
            // 
            this.btnNouveauS.Location = new System.Drawing.Point(309, 37);
            this.btnNouveauS.Margin = new System.Windows.Forms.Padding(2);
            this.btnNouveauS.Name = "btnNouveauS";
            this.btnNouveauS.Size = new System.Drawing.Size(74, 20);
            this.btnNouveauS.TabIndex = 4;
            this.btnNouveauS.Text = "Nouveau";
            this.btnNouveauS.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(129, 69);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Name = "textBox1";
            this.textBox1.PasswordChar = '*';
            this.textBox1.Size = new System.Drawing.Size(132, 20);
            this.textBox1.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 72);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Prenom :";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(129, 117);
            this.textBox2.Margin = new System.Windows.Forms.Padding(2);
            this.textBox2.Name = "textBox2";
            this.textBox2.PasswordChar = '*';
            this.textBox2.Size = new System.Drawing.Size(132, 20);
            this.textBox2.TabIndex = 7;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(129, 141);
            this.textBox3.Margin = new System.Windows.Forms.Padding(2);
            this.textBox3.Name = "textBox3";
            this.textBox3.PasswordChar = '*';
            this.textBox3.Size = new System.Drawing.Size(132, 20);
            this.textBox3.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 120);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Salaire Brut :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(14, 144);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 13);
            this.label8.TabIndex = 10;
            this.label8.Text = "Taux CS :";
            // 
            // chkCompteBloque
            // 
            this.chkCompteBloque.AutoSize = true;
            this.chkCompteBloque.Location = new System.Drawing.Point(138, 211);
            this.chkCompteBloque.Margin = new System.Windows.Forms.Padding(2);
            this.chkCompteBloque.Name = "chkCompteBloque";
            this.chkCompteBloque.Size = new System.Drawing.Size(97, 17);
            this.chkCompteBloque.TabIndex = 4;
            this.chkCompteBloque.Text = "Compte bloqué";
            this.chkCompteBloque.UseVisualStyleBackColor = true;
            // 
            // FrmSalaries
            // 
            this.AcceptButton = this.btnValider;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnAnnuler;
            this.ClientSize = new System.Drawing.Size(523, 445);
            this.Controls.Add(this.gbDetailSalarié);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbSalarié);
            this.Controls.Add(this.btnNouveauS);
            this.Name = "FrmSalaries";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FrmSalaries";
            this.gbDetailSalarié.ResumeLayout(false);
            this.gbDetailSalarié.PerformLayout();
            this.pnlBoutons.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbDetailSalarié;
        private System.Windows.Forms.Panel pnlBoutons;
        private System.Windows.Forms.Button btnValider;
        private System.Windows.Forms.Button btnAnnuler;
        private System.Windows.Forms.Button btnModifier;
        private System.Windows.Forms.TextBox txtNomS;
        private System.Windows.Forms.TextBox txtDateNaissance;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMatricule;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbSalarié;
        private System.Windows.Forms.Button btnNouveauS;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.CheckBox chkCompteBloque;
    }
}